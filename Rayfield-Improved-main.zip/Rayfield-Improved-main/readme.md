# Rayfield Improved V1.3

My job is to make sure Rayfield is as good as possible, and i wanted to develop this to help users!

# RAYFIELD DOCS!

[This](https://docs.sirius.menu/rayfield) is Rayfield's official documentation.

# UPDATE LOGS
+ Changed some images
+ Key system notification on correct key.
+ New themes

# ALL NEW THEMES
+ "AMOLED"
+ "AMOLEDPurple"
+ "Purpleset"
